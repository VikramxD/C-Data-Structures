
#include<stdio.h>
#include<stdlib.h>

struct Node{
    int Data;
    struct Node*next;
}*first=NULL;

const char * Sorted_Insert(struct Node*p, int x){
    struct Node*t;
    struct Node*q=NULL;
    t=(struct Node *)malloc(sizeof(struct Node));
    t->Data=x;
    t->next=NULL;
    if(first==NULL){
        first=t;
    }
    else{
        while(p && p->Data<x){
            q=p;
            p=p->next;
        }
        if(p==first){
            t->next=first;
            first=t;

        }
        else{
            t->next=q->next;
            q->next=t;
        }
    }

}
void create(int A[],int n){
    struct Node*t;
    struct Node*last;
    first=(struct Node*)malloc(sizeof(struct Node));
    first->Data=A[0];
    first->next=NULL;
    last=first;
    for(int i=1; i<n; i++){
        t=(struct Node*)malloc(sizeof(struct Node));
        t->Data=A[i];
        last->next=t;
        last=t;

    }
}

void Display(struct Node*p){
    while(p!=NULL){
        printf("%d\n", p->Data);
        p=p->next;

    }
}

int main(){
    int A[]={12,24,36,56,100};
    create(A,5);
    Sorted_Insert(first,23);
    Display(first);
    return 0;
}